love.graphics.setDefaultFilter("nearest","nearest")

common = {images = {},sounds = {}}

for i, v in ipairs(love.filesystem.getDirectoryItems("assets/images")) do
	common.images[v] = love.graphics.newImage("assets/images/"..v)
end
for i, v in ipairs(love.filesystem.getDirectoryItems("assets/sounds")) do
	common.sounds[v] = love.audio.newSource("assets/sounds/"..v,"static")
end

local configs = {}
for i, v in ipairs(love.filesystem.getDirectoryItems("pieces")) do
  configs[v] = require ("pieces/"..v)
  configs[i] = configs[v]
end

game = {
width = 720,
height = 720,
pieces = {},
move = {},
turn = 0,
tick = 0,
}

local selected

local board_color = {{1,1,1},{.5,.5,1}}

local function getOccupant(x,y,ignore)
  for i, v in ipairs(game.pieces) do
    if v.x == x and v.y == y and v ~= ignore then
      return v
    end
  end
end

local function danger(x,y,wish)
  local ox, oy
  local team
  if wish then
    ox, oy = wish[1].x, wish[1].y
    team = wish[1].team
    if ox == x and oy == y then
      x, y = wish[2], wish[3]
    end
    wish[1].x = wish[2]
    wish[1].y = wish[3]
  end
  for i, v in ipairs(game.pieces) do
    if v.team ~= team then
      local squares = configs[v.class].getLegalMoves(v)
      for i, sq in ipairs(squares) do
        if sq[1] == x and sq[2] == y and (v.x ~= wish[2] or v.y ~= wish[3]) and not v.dying then
          if ox then
            wish[1].x = ox
            wish[1].y = oy
          end
          return true
        end
      end
    end
  end
  if ox then
    wish[1].x = ox
    wish[1].y = oy
  end
  return false
end

local function getViewportOffset()
  local screenWidth, screenHeight = love.graphics.getDimensions()

  local screenScaling = math.min(screenWidth/game.width,screenHeight/game.height)
  local offsetX = (screenWidth - (game.width * screenScaling)) / 2
  local offsetY = (screenHeight - (game.height * screenScaling)) / 2

  return screenScaling, offsetX, offsetY
end

local function fardingbord(y,swap)
  for i=1,8 do
    local i = i - 1
    if (i/2 == math.floor(i/2) and swap ~= true) or (swap == true and i/2 ~= math.floor(i/2))then
      love.graphics.setColor(board_color[1][1],board_color[1][2],board_color[1][3],1)
    else
      love.graphics.setColor(board_color[2][1],board_color[2][2],board_color[2][3],1)
    end
    love.graphics.rectangle("fill",i*game.width/8,y*game.height/8,game.width/8,game.height/8)
  end
end

local function render()
  fardingbord(0)
  fardingbord(2)
  fardingbord(4)
  fardingbord(6)
  fardingbord(1,true)
  fardingbord(3,true)
  fardingbord(5,true)
  fardingbord(7,true)
  love.graphics.push()
  love.graphics.translate(game.width/16,game.height/16)
  if game.royal0 and game.royal0.ischeck then
    love.graphics.setColor(.6,0,0)
    local t = game.width/8
    love.graphics.rectangle("fill",game.royal0.x*t-t/2,game.royal0.y*t-t/2,t,t)
  end
  if game.royal1 and game.royal1.ischeck then
    love.graphics.setColor(.6,0,0)
    local t = game.width/8
    love.graphics.rectangle("fill",game.royal1.x*t-t/2,game.royal1.y*t-t/2,t,t)
  end
  love.graphics.setColor(1,1,1)
  for i, v in ipairs(game.pieces) do
    if v.dying then
      configs[v.class].draw(v)
    end
  end
  for i, v in ipairs(game.pieces) do
    if not v.dying then
      configs[v.class].draw(v)
    end
  end
  love.graphics.setColor(0,0,0,.5)
  if selected then
    for i, v in ipairs(game.move) do
      love.graphics.circle("fill",v[1]*game.width/8,v[2]*game.width/8,20)
    end
  end
  love.graphics.pop()
end

local function checkIfMated()
  local royal = (game.royal0.ischeck and game.royal0) or (game.royal1.ischeck and game.royal1)
  local possible = 0

  for i, v in ipairs(game.pieces) do
    if v.team == royal.team then
      local move = configs[v.class].getLegalMoves(v)
        for i, wish in ipairs(move) do
          local occupant = getOccupant(wish[1],wish[2])
          if (occupant == nil or occupant.team ~= v.team) and not danger(royal.x,royal.y,{v,wish[1],wish[2]}) then
            possible = possible + 1
          end
        end
      end
  end

  if possible == 0 then
    common.sounds["GenericNotify.ogg"]:play()
    print("checkmate")
  end

end

local function newPiece(class,team,x,y)
  local p = {
  class = class or "",
  team = team or 0,
  x = x or 0,
  y = y or 0,
  old_x = 0,
  old_y = 0,
  moved_at = 0,
  }
  game.pieces[#game.pieces+1] = p
  return p
end

function love.load()
  game.royal0 = newPiece("king",0,3,0)
  newPiece("queen",0,4,0)
  newPiece("bishop",0,5,0)
  newPiece("bishop",0,2,0)
  newPiece("rook",0,0,0)
  newPiece("rook",0,7,0)
  newPiece("knight",0,1,0)
  newPiece("knight",0,6,0)
  for i=0,7 do
    newPiece("pawn",0,i,1)
  end

    game.royal1 = newPiece("king",1,3,7)
  newPiece("queen",1,4,7)
  newPiece("bishop",1,5,7)
  newPiece("bishop",1,2,7)
  newPiece("rook",1,0,7)
  newPiece("rook",1,7,7)
  newPiece("knight",1,1,7)
  newPiece("knight",1,6,7)
  for i=0,7 do
    newPiece("pawn",1,i,6)
  end
end

function love.draw()

	local screenScaling, offsetX, offsetY = getViewportOffset()
	love.graphics.push()
	love.graphics.translate(offsetX,offsetY)
	love.graphics.scale(screenScaling)

	render()

	love.graphics.pop()
end

function love.update()
  game.tick = game.tick + 1
end

function love.mousepressed(x,y)
  local screenScaling, offsetX, offsetY = getViewportOffset()
  local world_x = (x - offsetX) / screenScaling
  local world_y = (y - offsetY) / screenScaling
  local tileSize = game.width/8
  local screenWidth, screenHeight = love.graphics.getDimensions()
  local tx, ty = math.floor(world_x/tileSize),math.floor(world_y/tileSize)
  if selected and selected.team == game.turn then
    for i, v in ipairs(game.move) do
      if v[1] == tx and v[2] == ty then
        configs[selected.class].move(selected,v)
        game.turn = (selected.team == 0 and 1) or 0
        selected = nil
        if game.royal0 and danger(game.royal0.x,game.royal0.y,{game.royal0,game.royal0.x,game.royal0.y}) then
          game.royal0.ischeck = true
          checkIfMated()
        else
          game.royal0.ischeck = nil
        end
        if game.royal1 and danger(game.royal1.x,game.royal1.y,{game.royal1,game.royal1.x,game.royal1.y}) then
          game.royal1.ischeck = true
          checkIfMated()
        else
          game.royal1.ischeck = nil
        end
        return
      end
    end
  end
  selected = nil
  for i, v in ipairs(game.pieces) do
    if v.x == tx and v.y == ty and selected == nil then
      selected = v
      game.move = configs[v.class].getLegalMoves(v)
      local royal = game["royal"..v.team]
      if royal then
        local new = {}
        for i, wish in ipairs(game.move) do
          local occupant = getOccupant(wish[1],wish[2])
          if (occupant == nil or occupant.team ~= v.team) and not danger(royal.x,royal.y,{v,wish[1],wish[2]}) then
            table.insert(new,wish)
          end
        end
        game.move = new
      end
      break
    end
  end
end