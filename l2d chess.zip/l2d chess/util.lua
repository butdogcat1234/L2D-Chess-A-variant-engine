local module = {}

function module.lerp(a,b,t)
  return a+(b-a)*t
end

function module.destroy(piece)
  local new = {}
  for i, v in ipairs(game.pieces) do
    if v ~= piece then
      table.insert(new,v)
    end
  end
  game.pieces = new
end

return module