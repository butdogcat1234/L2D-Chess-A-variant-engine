local directory = "pieces/queen"
local util = require "util"

local module = {}

local black,white = love.graphics.newImage(directory.."/black.png"), love.graphics.newImage(directory.."/white.png")

module.display_name = "Queen"

local function getOccupant(x,y,ignore)
  for i, v in ipairs(game.pieces) do
    if v.x == x and v.y == y and v ~= ignore then
      return v
    end
  end
end

function module.draw(piece)
  local t = (game.tick-piece.moved_at)/6
  local r = (game.turn == 0 and 180) or 0 -- for local play
  if t > 1 or piece.moved_at == 0 then
    t = 1
  end
  local occupant = getOccupant(piece.x,piece.y,piece)
  if game.tick-piece.moved_at == 6 then
    util.destroy(occupant)
  end
  love.graphics.draw((piece.team==0 and white) or black,util.lerp(piece.old_x,piece.x,t)*game.width/8,util.lerp(piece.old_y,piece.y,t)*game.height/8,math.rad(r),.7,.7,64,64)
end

function module.getLegalMoves(piece)
  local squares = {}
  for i=1,7 do
    table.insert(squares,{piece.x+i,piece.y})
    if getOccupant(piece.x+1,piece.y) then
      break
    end
  end

  for i=1,7 do
    table.insert(squares,{piece.x-i,piece.y})
    if getOccupant(piece.x-i,piece.y) then
      break
    end
  end

  for i=1,7 do
    table.insert(squares,{piece.x,piece.y+i})
    if getOccupant(piece.x,piece.y+i) then
      break
    end
  end

  for i=1,7 do
    table.insert(squares,{piece.x,piece.y-i})
    if getOccupant(piece.x,piece.y-i) then
      break
    end
  end

  for i=1,7 do
    table.insert(squares,{piece.x+i,piece.y+i})
    if getOccupant(piece.x+i,piece.y+i) then
      break
    end
  end

  for i=1,7 do
    table.insert(squares,{piece.x+i,piece.y-i})
    if getOccupant(piece.x+i,piece.y-i) then
      break
    end
  end

  for i=1,7 do
    table.insert(squares,{piece.x-i,piece.y+i})
    if getOccupant(piece.x-i,piece.y+i) then
      break
    end
  end

  for i=1,7 do
    table.insert(squares,{piece.x-i,piece.y-i})
    if getOccupant(piece.x-i,piece.y-i) then
      break
    end
  end

  local new = {}
  for i, v in ipairs(squares) do
    local occupant = getOccupant(v[1],v[2])
    if v[1] >= 0 and v[1] < 8 and v[2] >= 0 and v[2] < 8 then
      table.insert(new,v)
    end
  end

  return new
end

function module.move(piece,pos)
  local occupant = getOccupant(pos[1],pos[2])
  piece.old_x = piece.x
  piece.old_y = piece.y
  piece.moved_at = game.tick
  piece.x = pos[1]
  piece.y = pos[2]
  
  if occupant then
    occupant.dying = true
    common.sounds["Capture.ogg"]:clone():play()
  else
    common.sounds["Move.ogg"]:clone():play()
  end
end

return module