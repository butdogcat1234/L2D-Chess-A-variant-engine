local directory = "pieces/pawn"
local util = require "util"

local module = {}

local black,white = love.graphics.newImage(directory.."/black.png"), love.graphics.newImage(directory.."/white.png")

module.display_name = "Pawn"

local function getOccupant(x,y,ignore)
  for i, v in ipairs(game.pieces) do
    if v.x == x and v.y == y and v ~= ignore then
      return v
    end
  end
end

function module.draw(piece)
  local t = (game.tick-piece.moved_at)/6
  local r = (game.turn == 0 and 180) or 0 -- for local play
  if t > 1 or piece.moved_at == 0 then
    t = 1
  end
  local occupant = getOccupant(piece.x,piece.y,piece)
  if game.tick-piece.moved_at == 6 then
    util.destroy(occupant)
  end
  love.graphics.draw((piece.team==0 and white) or black,util.lerp(piece.old_x,piece.x,t)*game.width/8,util.lerp(piece.old_y,piece.y,t)*game.height/8,math.rad(r),.7,.7,64,64)
end

function module.getLegalMoves(piece)
  local squares = {}
  local mult = (piece.team==1 and -1) or 1
  for y=1,2 do
    y = y * mult
    local occupant = getOccupant(piece.x,piece.y+y)
    if occupant or (math.abs(y)==2 and piece.moved) then break end
    table.insert(squares,{piece.x,y+piece.y})
  end
  local hit1 = getOccupant(piece.x+1,piece.y+mult)
  local hit2 = getOccupant(piece.x-1,piece.y+mult)

  if hit1 then
    table.insert(squares,{piece.x+1,piece.y+mult})
  end

  if hit2 then
    table.insert(squares,{piece.x-1,piece.y+mult})
  end

  local new = {}
  for i, v in ipairs(squares) do
    local occupant = getOccupant(v[1],v[2])
    if v[1] >= 0 and v[1] < 8 and v[2] >= 0 and v[2] < 8 then
      table.insert(new,v)
    end
  end

  return new
end

function module.move(piece,pos)
  local occupant = getOccupant(pos[1],pos[2])
  piece.old_x = piece.x
  piece.old_y = piece.y
  piece.moved_at = game.tick
  piece.x = pos[1]
  piece.y = pos[2]
  piece.moved = true
  
  if occupant then
    occupant.dying = true
    common.sounds["Capture.ogg"]:clone():play()
  else
    common.sounds["Move.ogg"]:clone():play()
  end
end

return module